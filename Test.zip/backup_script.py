
from dotenv import dotenv_values
import subprocess
import datetime
from datetime import date
config = dotenv_values(".env")
backup_dir = "backup"
def create_backup_filename(db_name):
    date_str = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    return f'./{backup_dir}/{db_name}_backup_{date_str}.sql'

def create_backup(config):
    if config:
        backup_file = create_backup_filename(config["DBNAME"])
        cmd = f"mysqldump -h {config["HOST"]} -u {config["USERNAME"]} -p{config["PASSWORD"]} {config["DBNAME"]} > {backup_file}"
        subprocess.run(cmd,check=True,shell=True)
        print(f'Database Backup created {backup_file}')
    else:
        print("no config defined")



config = dotenv_values(".env")
create_backup(config)
