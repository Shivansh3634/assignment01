

from dotenv import dotenv_values
import mysql.connector
import os
config = dotenv_values(".env")
MYSQL_CONFIG = {
    'host': config["HOST"],
    'user': config["USERNAME"],
    'password': config["PASSWORD"],
    'database': config["DBNAME"],
    'port': 3306
}


MIGRATIONS_DIR = "migrations"

def connect():
    return mysql.connector.connect(**MYSQL_CONFIG)

def ensure_migration_table(cursor):
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS schema_migrations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            filename VARCHAR(255) NOT NULL UNIQUE
        )
    """)

def get_applied_migration(cursor):
    cursor.execute("SELECT filename from schema_migrations")
    return [row[0] for row in cursor.fetchall()]


def apply_migration(cursor,filename,query):
    statements = query.split(";")
    for stmt in statements:
        stripped_stmt = stmt.strip()
        cursor.execute(stripped_stmt)
    cursor.execute(f"INSERT INTO `schema_migrations`( `filename`) VALUES ('{filename}')")
    print(f"deployed migration {filename}")

def deploy_migrations():
        try:
            conn = connect()
            cursor = conn.cursor()
            ensure_migration_table(cursor)
            applied_migrations = get_applied_migration(cursor)
            migration_files = sorted(f for f in os.listdir(MIGRATIONS_DIR) if f.endswith(".sql") and f not in applied_migrations)
            if len(migration_files) == 0:
                print("no migrations to apply.")
            for file in migration_files:
                with open(os.path.join(MIGRATIONS_DIR,file),"r") as f:
                    query = f.read()
                    try:
                        apply_migration(cursor,file,query)
                        conn.commit()
                    except Exception as ex:
                        print(f"error occured : {ex}")
                        conn.rollback()
        except Exception as ex:
            print(f"Connection Error: {ex}")


deploy_migrations()
