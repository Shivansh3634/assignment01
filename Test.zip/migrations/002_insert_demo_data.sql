INSERT INTO `test_table` (`Name`) VALUES
('Alice Johnson'),
('Bob Smith'),
('Charlie Davis'),
('Diana Perez'),
('Ethan Clark'),
('Fiona Adams'),
('George Martin'),
('Hannah Brown'),
('Ian Wright'),
('Julia Roberts'),
('Kevin Turner'),
('Laura Green'),
('Michael Scott');
